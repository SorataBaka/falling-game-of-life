import controller.SimulationController;
public class FGameOfLife {
    public static void main(String[] args){
        new SimulationController();
    }
}